﻿Polymarket 公開交易調查 — 律師會議資料包

一、建議閱讀順序
1. 先讀本檔的重點與限制。
2. 開啟 Polymarket_transaction_evidence.xlsx：Summary → Candidate timelines → Categories → Transactions。
3. 詳細證據及方法見 Evidence_Summary_zh_TW.md（一般文字編輯器也可開啟）。
4. 需要核對時，用 CSV 的完整 transaction hash／explorer URL，並對照 Public_evidence_raw.zip。

二、取證範圍
原地址：0x0035c14b28cdc7be457ae15da190e858d7e35b44
有鏈上資金關聯的交易錢包：0xbacf48c67136b5b21fd72ca8e2178faf8759306d
交易查詢截止：2026/10/01 14:39:08 台灣時間（UTC+8）。
本資料包整合前次取證，未因重新打包而更新查詢截止。

三、主要事實
• 原地址於9月三筆入金合計320 USDC.e，在同一批交易中轉為320 pUSD給交易錢包。
• 該交易錢包最早查得交易：2026/04/08 15:51:59 台灣時間，同秒兩筆。
• 嚴格早於9/30零時：959筆TRADE、447個市場、10個研究分類。
• 含9/30全日：968筆TRADE；台灣選舉4筆，占0.4132%。
• 嚴格9/30以前台灣選舉：2筆，占959筆的0.2086%。
• 台灣選舉BUY支出103.04867，占全部BUY支出2755.621536的3.739580%。
• 蘇巧慧：9/25 21:51:06 BUY；9/30 11:31:50 SELL。
• 沈伯洋：9/25 21:50:50 BUY；9/30 11:33:06 SELL。
• 9/30全部9筆TRADE均為SELL，另外7筆屬非台灣選舉市場。
• 10/1零時至查詢截止，API未回傳TRADE。

四、盈虧（四筆候選人交易的實際資產為pUSD）
沈伯洋 Total Buy 51.61173；Total Sell 42.04293。
蘇巧慧 Total Buy 51.43694；Total Sell 58.88908。
實際收支差額：
沈伯洋＝42.04293－51.61173＝-9.56880。
蘇巧慧＝58.88908－51.43694＝+7.45214。
Combined＝-9.56880＋7.45214＝-2.11666 pUSD。

因仍有少量shares殘餘，已售部分的比例成本法另列：
沈伯洋＝42.04293－51.61173×257.55÷257.557789＝-9.56723917。
蘇巧慧＝58.88908－51.43694×177.6÷177.602069＝+7.45273922。
Combined realized P&L＝-2.11449995 pUSD。
API realized_pnl合計為-2.1146；各口徑及精度差異已在報告說明。
蘇巧慧獲利、沈伯洋虧損，虧損大於獲利，合計淨虧損。

五、討論時必須保留的區別
• 你表示記憶中9月才開始跑程式。已確認原地址的資金連結在9月；4月紀錄屬接收資金的交易錢包。不能據此倒推4月交易由你操作，或程式4月已啟動。
• 地址間資金流不等於同一自然人控制的證明。
• 紀錄分布於4月與9月，5–8月API未回傳TRADE；不稱為每天連續交易。
• TRADE列不等於原始訂單數。公開資料未完整呈現撤单、未成交訂單及下單裝置。
• 兩筆SELL出售絕大部分shares，仍有微量殘餘，不能寫成嚴格全部歸零。
• 968筆TRADE已在API v1/v2間核對一致；不是全部歷史鏈上事件的逐筆獨立稽核。已逐筆核對的重點交易及其餘限制見完整報告。
• 市場分散、小額及短間隔成交可作為模式觀察，不能證明使用bot或任何主觀意圖。
• 不提供法律責任結論。

六、八項要求對應檔案
1. Complete transaction table：Complete_transaction_table.csv；Excel Transactions。
2. Market-category statistics：Market_category_statistics.csv；Market_inventory.csv；Excel Categories／Markets。
3. Puma Shen timeline：Puma_Shen_timeline.csv；Excel Candidate timelines。
4. Su Chiao-hui timeline：Su_Chiao_hui_timeline.csv；Excel Candidate timelines。
5. Combined P&L：本檔第四節；完整報告第5節；Excel Candidate timelines公式。
6. 9/30前後時間線：完整報告第6節；交易表Period A/B/C；September_30_timeline.csv。
7. Evidence Summary：Evidence_Summary_zh_TW.md。
8. 來源與連結：Sources.csv、完整報告第9節、Public_evidence_raw.zip中的sources.jsonl與SHA256_manifest.json。

七、檔案完整性
PACKAGE_SHA256.json列出包內每份檔案的SHA-256。
Public_evidence_raw.zip另有原始下載檔案的SHA-256及查詢來源。
雜湊用於檢查保存檔案是否變更，不等於公證或第三方時間戳。
